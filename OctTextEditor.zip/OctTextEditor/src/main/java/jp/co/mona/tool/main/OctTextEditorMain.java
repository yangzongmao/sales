package jp.co.mona.tool.main;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

public class OctTextEditorMain {
    private JFrame frame;
    private JTable dataTable;
    private DefaultTableModel tableModel;
    private List<String[]> dataLines;
    private List<String> columnDefinitions;
    private int currentPage = 0;
    private static final int LINES_PER_PAGE = 10;

    public OctTextEditorMain() {
        frame = new JFrame("Fixed Length Data Editor");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(new BorderLayout());

        // Create Table Model
        tableModel = new DefaultTableModel();
        dataTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(dataTable);

        // Create Navigation Panel
        JPanel navPanel = new JPanel();
        JButton prevButton = new JButton("上一页");
        JButton nextButton = new JButton("下一页");
        navPanel.add(prevButton);
        navPanel.add(nextButton);

        // Add components to frame
        frame.add(scrollPane, BorderLayout.CENTER);
        frame.add(navPanel, BorderLayout.SOUTH);

        // Create Menu Bar
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("文件");
        JMenuItem openDatasetItem = new JMenuItem("打开数据集");
        JMenuItem openLayoutItem = new JMenuItem("打开布局定义");
        JMenuItem saveItem = new JMenuItem("保存");
        JMenuItem exitItem = new JMenuItem("退出");

        openDatasetItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openDatasetFile();
            }
        });

        openLayoutItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openLayoutFile();
            }
        });

        saveItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveData();
            }
        });

        exitItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        fileMenu.add(openDatasetItem);
        fileMenu.add(openLayoutItem);
        fileMenu.add(saveItem);
        fileMenu.add(exitItem);
        menuBar.add(fileMenu);
        frame.setJMenuBar(menuBar);

        // Add Action Listeners for Navigation Buttons
        prevButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (currentPage > 0) {
                    currentPage--;
                    updatePage();
                }
            }
        });

        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (dataLines != null && (currentPage + 1) * LINES_PER_PAGE < dataLines.size()) {
                    currentPage++;
                    updatePage();
                }
            }
        });

        frame.setVisible(true);
    }

    private void openDatasetFile() {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(frame);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            loadData(file.getAbsolutePath());
            currentPage = 0;
            updatePage();
        }
    }

    private void openLayoutFile() {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(frame);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            loadLayout(file.getAbsolutePath());
            updatePage();
        }
    }

    private void saveData() {
        // Implement saving logic if needed
        JOptionPane.showMessageDialog(frame, "保存功能尚未实现");
    }

    private void loadData(String filePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            dataLines = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                dataLines.add(line.split(""));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadLayout(String filePath) {
        columnDefinitions = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                columnDefinitions.add(line.trim());
            }
            updateTableHeaders();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void updateTableHeaders() {
        tableModel.setColumnCount(columnDefinitions.size());
        tableModel.setColumnIdentifiers(columnDefinitions.toArray());
    }

    private void updatePage() {
        tableModel.setRowCount(0);
        int startLine = currentPage * LINES_PER_PAGE;
        int endLine = Math.min(startLine + LINES_PER_PAGE, dataLines.size());

        for (int i = startLine; i < endLine; i++) {
            String[] line = dataLines.get(i);
            tableModel.addRow(line);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(OctTextEditorMain::new);
    }
}


