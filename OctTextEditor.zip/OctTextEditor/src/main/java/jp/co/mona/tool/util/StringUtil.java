package jp.co.mona.tool.util;

public class StringUtil {
	public static String toHex(String text) {
		StringBuilder hex = new StringBuilder();
		for (char c : text.toCharArray()) {
			hex.append(String.format("%02X", (int) c));
		}
		return hex.toString();
	}

	public static String bytesToHexString(byte[] byteArray) {
		StringBuilder hexString = new StringBuilder();
		for (byte b : byteArray) {
			String hex = Integer.toHexString(b & 0xFF).toUpperCase();
			if (hex.length() == 1) {
				hexString.append('0'); // Pad with leading zero if needed
			}
			hexString.append(hex);
		}
		return hexString.toString();
	}

	/**
	* Checks if a CharSequence is empty ("") or null.
	*
	* <pre>
	* StringUtils.isEmpty(null)      = true
	* StringUtils.isEmpty("")        = true
	* StringUtils.isEmpty(" ")       = false
	* StringUtils.isEmpty("bob")     = false
	* StringUtils.isEmpty("  bob  ") = false
	* </pre>
	*
	* <p>NOTE: This method changed in Lang version 2.0.
	* It no longer trims the CharSequence.
	* That functionality is available in isBlank().</p>
	*
	* @param cs  the CharSequence to check, may be null
	* @return {@code true} if the CharSequence is empty or null
	* @since 3.0 Changed signature from isEmpty(String) to isEmpty(CharSequence)
	*/
	public static boolean isEmpty(final CharSequence cs) {
		return cs == null || cs.length() == 0;
	}
}
