package jp.co.mona.tool.main;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.EventObject;
import java.util.List;

import javax.swing.AbstractCellEditor;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.event.MouseInputAdapter;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

import jp.co.mona.tool.util.StringUtil;

public class FixedLengthDataEditor extends JFrame {
	private JTable table;
	private FixedLengthTableModel tableModel;
	private List<String[]> data;
	private int currentPage;
	private int rowsPerPage = 10;
	private int columnCount;

	public FixedLengthDataEditor() {
		setTitle("Fixed Length Data Editor");
		setSize(800, 600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);

		JMenuBar menuBar = new JMenuBar();
		JMenu menu = new JMenu("File");
		JMenuItem openItem = new JMenuItem("Open");
		JMenuItem saveItem = new JMenuItem("Save");
		JMenuItem exitItem = new JMenuItem("Exit");

		openItem.addActionListener(e -> openFile());
		saveItem.addActionListener(e -> saveFile());
		exitItem.addActionListener(e -> System.exit(0));

		menu.add(openItem);
		menu.add(saveItem);
		menu.add(exitItem);
		menuBar.add(menu);
		setJMenuBar(menuBar);

		tableModel = new FixedLengthTableModel();
		table = new JTable(tableModel);
		table.setRowHeight(60);
		// table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		JScrollPane scrollPane = new JScrollPane(table);
		add(scrollPane, BorderLayout.CENTER);

		JPanel controlPanel = new JPanel();
		JButton prevButton = new JButton("Previous");
		JButton nextButton = new JButton("Next");

		prevButton.addActionListener(e -> loadPage(currentPage - 1));
		nextButton.addActionListener(e -> loadPage(currentPage + 1));

		controlPanel.add(prevButton);
		controlPanel.add(nextButton);
		add(controlPanel, BorderLayout.SOUTH);

		data = new ArrayList<>();
		currentPage = 0;
	}

	private void openFile() {
		JFileChooser fileChooser = new JFileChooser();
		int result = fileChooser.showOpenDialog(this);
		if (result == JFileChooser.APPROVE_OPTION) {
			File dataFile = fileChooser.getSelectedFile();
			// Assume the layout file is selected after the data file
			result = fileChooser.showOpenDialog(this);
			if (result == JFileChooser.APPROVE_OPTION) {
				File layoutFile = fileChooser.getSelectedFile();
				loadData(dataFile, layoutFile);
				loadPage(0);
			}
		}
	}

	private void saveFile() {
		JFileChooser fileChooser = new JFileChooser();
		int result = fileChooser.showSaveDialog(this);
		if (result == JFileChooser.APPROVE_OPTION) {
			File file = fileChooser.getSelectedFile();
			saveData(file);
		}
	}

	private void loadData(File dataFile, File layoutFile) {
		try (BufferedReader dataReader = new BufferedReader(new FileReader(dataFile));
				BufferedReader layoutReader = new BufferedReader(new FileReader(layoutFile))) {

			data.clear();
			tableModel.setRowCount(0);
			tableModel.setColumnCount(0);

			String layoutLine;
			List<Integer> columnWidths = new ArrayList<>();
			while ((layoutLine = layoutReader.readLine()) != null) {
				// Assuming each line in the layout file defines the width of a column
				columnWidths.add(Integer.parseInt(layoutLine.trim()));
			}

			columnCount = columnWidths.size() + 1;
			String colHeaderName = "";
			for (int i = 0; i < columnCount; i++) {
				if (i == 0) {
					colHeaderName = "No.";
				} else {
					colHeaderName = "Col " + (i + 1);
				}
				tableModel.addColumn(colHeaderName);
			}

			String dataLine;
			int rowIndex = 1;
			while ((dataLine = dataReader.readLine()) != null) {
				int totalLength = columnWidths.stream().mapToInt(Integer::intValue).sum();
				if (dataLine.length() < totalLength) {
					continue; // Skip incomplete lines
				}

				// String[] rowHex = new String[columnCount];
				String[] rowText = new String[columnCount];

				// rowHex[0] = String.valueOf(rowIndex);
				rowText[0] = String.valueOf(rowIndex);

				int pos = 0;
				for (int i = 1; i < columnCount; i++) {
					int width = columnWidths.get(i - 1);
					String segment = dataLine.substring(pos, pos + width);
					// rowHex[i] = toHex(segment);
					rowText[i] = segment;
					pos += width;
				}
				// data.add(rowHex);
				data.add(rowText);

				rowIndex++;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		JTableHeader header = table.getTableHeader();
		header.setReorderingAllowed(false);
		TableCellRenderer hr = header.getDefaultRenderer();
		TableColumn tableColumn = table.getColumnModel().getColumn(0);
		tableColumn.setCellRenderer(new HeaderRenderer(table, hr));

		int columnCount = table.getColumnModel().getColumnCount();
		for (int columnIndex = 1; columnIndex < columnCount; columnIndex++) {
			table.getColumnModel().getColumn(columnIndex).setCellRenderer(new TwoTextFieldRenderer());
			table.getColumnModel().getColumn(columnIndex).setCellEditor(new TwoTextFieldEditor());
		}
	}

	private void saveData(File file) {
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
			for (int i = 0; i < data.size(); i += 2) {
				String[] rowText = data.get(i + 1);
				for (String text : rowText) {
					writer.write(text);
				}
				writer.newLine();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void loadPage(int page) {
		if (page < 0 || page * rowsPerPage >= data.size()) {
			return;
		}
		currentPage = page;
		tableModel.setRowCount(0);
		for (int i = 0; i < rowsPerPage; i++) {
			if (currentPage * rowsPerPage + i < data.size()) {
				tableModel.addRow(data.get(currentPage * rowsPerPage + i));
			}
		}
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			FixedLengthDataEditor editor = new FixedLengthDataEditor();
			editor.setVisible(true);
		});
	}

	class FixedLengthTableModel extends DefaultTableModel {
		@Override
		public boolean isCellEditable(int row, int column) {
			return true;
		}
	}

	class HeaderRenderer implements TableCellRenderer {
		private final TableCellRenderer tcr;

		public HeaderRenderer(JTable table, TableCellRenderer tcr) {
			this.tcr = tcr;
			RollOverListener rol = new RollOverListener();
			table.addMouseListener(rol);
			table.addMouseMotionListener(rol);
		}

		@Override
		public Component getTableCellRendererComponent(JTable tbl, Object val, boolean isS, boolean hasF, int row,
				int col) {

			boolean flg = row == rollOverRowIndex;
			JLabel jLabel = (JLabel) tcr.getTableCellRendererComponent(tbl, val, isS, flg ? flg : hasF, row, col);
			jLabel.setOpaque(!flg);
			return jLabel;
		}

		private int rollOverRowIndex = -1;

		private class RollOverListener extends MouseInputAdapter {
			@Override
			public void mouseExited(MouseEvent e) {
				rollOverRowIndex = -1;
				JTable table = (JTable) e.getSource();
				table.repaint();
			}

			@Override
			public void mouseMoved(MouseEvent e) {
				JTable table = (JTable) e.getSource();
				Point pt = e.getPoint();
				int column = table.columnAtPoint(pt);
				rollOverRowIndex = (column == 0) ? table.rowAtPoint(pt) : -1;
				table.repaint();
			}

			@Override
			public void mouseDragged(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseReleased(MouseEvent e) {
			}
		}
	}

	static class TwoTextFieldPanel extends JPanel {
		JTextField hexField;
		JTextField textField;

		public TwoTextFieldPanel() {
			setLayout(new GridLayout(2, 1));

			Border lineBorder = BorderFactory.createLineBorder(Color.gray, 2);
			Border emptyBorder = new EmptyBorder(0, 5, 0, 5);
			CompoundBorder compoundBorder = new CompoundBorder(lineBorder, emptyBorder);

			hexField = new JTextField();
			hexField.setBorder(compoundBorder);
			hexField.setEnabled(false);

			textField = new JTextField();
			textField.setBorder(compoundBorder);
			add(hexField);
			add(textField);
		}

		public String getText() {
			return textField.getText();
		}

		public void setText(String text) {
			textField.setText(text);
		}

		public String getHex() {
			return hexField.getText();
		}

		public void setHex(String text) {
			hexField.setText(text);
		}
	}

	static class TwoTextFieldRenderer extends DefaultTableCellRenderer {
		@Override
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
				int row, int column) {
			TwoTextFieldPanel panel = new TwoTextFieldPanel();
			if (value instanceof String) {
				String textValue = String.valueOf(value);
				String hexValue = StringUtil.toHex(textValue);
				panel.setText(textValue);
				panel.setHex(hexValue);
			}
			return panel;
		}
	}

	static class TwoTextFieldEditor extends AbstractCellEditor implements TableCellEditor {
		private final TwoTextFieldPanel panel;

		public TwoTextFieldEditor() {
			panel = new TwoTextFieldPanel();
		}

		@Override
		public Object getCellEditorValue() {
			return panel.getText();
		}

		@Override
		public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row,
				int column) {
			if (value instanceof String) {
				String textValue = String.valueOf(value);
				String hexValue = StringUtil.toHex(textValue);
				panel.setText(textValue);
				panel.setHex(hexValue);
			}
			return panel;
		}

		@Override
		public boolean isCellEditable(EventObject anEvent) {
			return true;
		}
	}
}
