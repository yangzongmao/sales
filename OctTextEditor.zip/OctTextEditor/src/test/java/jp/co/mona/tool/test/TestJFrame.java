package jp.co.mona.tool.test;

public class TestJFrame {

}
