package jp.co.mona.tool.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CharsetEncoder;

import jp.co.mona.tool.util.StringUtil;

public class EUCJPCharacters {

	public static void main(String[] args) {

		//		char kana = 'ｱ';
		//		try {
		//			byte[] sjisBytes = String.valueOf(kana).getBytes("MS932");
		//			// String hex = Integer.toHexString(ch);
		//			for (int i = 0; i < sjisBytes.length; i++) {
		//				System.out.printf("%02X ", sjisBytes[i]);
		//			}
		//			System.out.println(new String(sjisBytes, "MS932"));
		//		} catch (Exception e) {
		//			// TODO: handle exception
		//		}
		
		String sjisCharsetName = "SJIS";
		Charset charset = Charset.forName(sjisCharsetName);
		CharsetEncoder encoder = charset.newEncoder();
		CharsetDecoder decoder = charset.newDecoder();
		for (int i = 1; i <= 65535; i++) {
			try {
				byte[] bytes = removeLeadingZeros(intToBytes(i));
				String sjisStr = new String(bytes, sjisCharsetName);
				if (!StringUtil.isEmpty(sjisStr) &&  sjisStr.length() == 1 && encoder.canEncode(sjisStr.charAt(0))) {
					byte[] sjisBytes = sjisStr.getBytes(sjisCharsetName);
					byte[] eucjpBytes = convertEncoding(sjisBytes, sjisCharsetName, "EUC-JP");
					String eucStr = new String(eucjpBytes, "EUC-JP");
					byte[] eucBytes = eucStr.getBytes("EUC-JP");
					System.out.println(StringUtil.bytesToHexString(sjisBytes) + "<<>>"
							+ StringUtil.bytesToHexString(eucBytes) + "[" + sjisStr
							+ "]" + "[" + i + "]");
				} else {
					// System.out.println("[" + i + "][" + StringUtil.bytesToHexString(bytes) + "]");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		//
		//		// Loop through a range of potential Unicode characters
		//		for (char ch = 0; ch < Character.MAX_VALUE; ch++) {
		//			// Check if the character can be encoded in EUC-JP
		//			System.out.println(Integer.toBinaryString(ch));
		//			if (encoder.canEncode(ch)) {
		//				try {
		//					// Encode the character to bytes
		//					ByteBuffer byteBuffer = encoder.encode(CharBuffer.wrap(new char[] { ch }));
		//					if (byteBuffer.limit() <= 2) {
		//						// Decode the bytes back to character
		//						CharBuffer charBuffer = decoder.decode(byteBuffer);
		//						// Print the character and its corresponding byte values
		//						System.out.print("Character: " + charBuffer + " | Bytes: ");
		//						for (int i = 0; i < byteBuffer.limit(); i++) {
		//							System.out.printf("%02X ", byteBuffer.get(i));
		//						}
		//						System.out.println();
		//					}
		//				} catch (Exception e) {
		//					// Handle encoding/decoding exceptions
		//					e.printStackTrace();
		//				}
		//			} else {
		//				try {
		//					byte[] sjisBytes = String.valueOf(ch).getBytes("MS932");
		//					// String hex = Integer.toHexString(ch);
		//					for (int i = 0; i < sjisBytes.length; i++) {
		//						System.out.printf("%02X ", sjisBytes[i]);
		//					}
		//					System.out.println(new String(sjisBytes, "MS932"));
		//				} catch (Exception e) {
		//					// TODO: handle exception
		//				}
		//			}
		//		}
	}

	//	public static byte[] intToBytes(int number) {
	//        int byteCount = (32 - Integer.numberOfLeadingZeros(number) + 7) / 8;
	//        byte[] result = new byte[byteCount];
	//        for (int i = 0; i < byteCount; i++) {
	//            result[byteCount - 1 - i] = (byte) (number >> (8 * i));
	//        }
	//        return result;
	//    }

	public static byte[] convertEncoding(byte[] inputBytes, String fromEncoding, String toEncoding) throws IOException {
		try (InputStream inputStream = new ByteArrayInputStream(inputBytes);
				ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {

			// Read input bytes using the fromEncoding
			String content = new String(inputStream.readAllBytes(), fromEncoding);

			// Convert content to the target encoding
			byte[] outputBytes = content.getBytes(toEncoding);

			// Write output bytes to output stream
			outputStream.write(outputBytes);

			return outputStream.toByteArray();
		}
	}

	public static byte[] intToBytes(int number) {
		ByteBuffer buffer = ByteBuffer.allocate(4);
		buffer.putInt(number);
		return buffer.array();
	}

	public static byte[] removeLeadingZeros(byte[] byteArray) {
		int nonZeroIndex = 0;
		while (nonZeroIndex < byteArray.length && byteArray[nonZeroIndex] == 0) {
			nonZeroIndex++;
		}

		byte[] result = new byte[byteArray.length - nonZeroIndex];
		System.arraycopy(byteArray, nonZeroIndex, result, 0, result.length);

		return result;
	}

	//	public static byte[] intToBytes(int number) {
	//		byte[] result = new byte[4];
	//		result[0] = (byte) (number >> 24);
	//		result[1] = (byte) (number >> 16);
	//		result[2] = (byte) (number >> 8);
	//		result[3] = (byte) number;
	//		return result;
	//	}

	//    public static byte[] intToBytes(int number) {
	//    	byte[] result = null;
	//        if (number <= 127) {
	//        	result = new byte[1];
	//        	result[0] = (byte) number;	
	//        } else {
	//        	result = new byte[2];
	//        	result[0] = (byte) (number >> 8);
	//        	result[1] = (byte) number;
	//        }
	////        result[0] = (byte) (number >> 24);
	////        result[1] = (byte) (number >> 16);
	////        result[2] = (byte) (number >> 8);
	//        return result;
	//    }
}
