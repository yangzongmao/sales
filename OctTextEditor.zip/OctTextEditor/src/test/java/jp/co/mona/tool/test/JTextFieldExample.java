package jp.co.mona.tool.test;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;

public class JTextFieldExample {

	public static void main(String[] args) {
		// 使用Swing的事件调度线程来创建和显示GUI
		SwingUtilities.invokeLater(() -> {
			// 创建一个新的JFrame
			JFrame frame = new JFrame("JTextField Example");
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setSize(400, 200);
			frame.setLayout(new FlowLayout()); // 设置布局管理器

			// 创建一个JTextField并设置初始文本
			JTextField textField = new JTextField("Enter text here", 20);
			
			Border line = BorderFactory.createLineBorder(Color.blue);
			Border empty = new EmptyBorder(10, 10, 10, 10);
			CompoundBorder border = new CompoundBorder(line, empty);
			textField.setBorder(border);
			// 添加一个按钮，用于显示文本框中的文本
			JButton button = new JButton("Show Text");
			button.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					// 显示文本框中的文本
					String text = textField.getText();
					JOptionPane.showMessageDialog(frame, "You entered: " + text);
				}
			});

			// 将文本框和按钮添加到框架中
			frame.add(textField);
			frame.add(button);

			// 显示框架
			frame.setVisible(true);
		});
	}
}
